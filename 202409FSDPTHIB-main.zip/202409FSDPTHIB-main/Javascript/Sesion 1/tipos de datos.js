let apellidos = 'Zaragoza Arranz';
let nombre = "Lopez";

let edad = 28;
let peso = 80.5;

let adulto = true;
let guapo = false;

let var1 = null;
let var2;

console.log(typeof peso);