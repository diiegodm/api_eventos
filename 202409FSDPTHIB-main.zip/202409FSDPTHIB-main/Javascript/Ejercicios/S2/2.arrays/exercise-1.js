const cars = ["Saab", "Volvo", "BMW"];

console.log(cars[1]);