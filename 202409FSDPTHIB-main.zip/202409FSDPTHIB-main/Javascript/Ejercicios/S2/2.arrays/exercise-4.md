Añade 2 elementos al array: "Morty" y "Summer". Muestra en consola el último personaje del array
```js
const rickAndMortyCharacters = ["Rick", "Beth", "Jerry"];
```
