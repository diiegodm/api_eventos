const cars = ['Saab', 'Volvo', 'BMW'];

cars[0] = 'Ford';