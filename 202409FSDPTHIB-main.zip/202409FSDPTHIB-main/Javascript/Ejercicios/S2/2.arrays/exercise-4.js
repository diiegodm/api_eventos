const rickAndMortyCharacters = ["Rick", "Beth", "Jerry"];

rickAndMortyCharacters.push('Morty', 'Summer');
let arrayLength = rickAndMortyCharacters.length;
console.log(rickAndMortyCharacters[arrayLength - 1]);