const placesToTravel = ['Japon', 'Venecia', 'Murcia', 'Santander', 'Filipinas', 'Madagascar'];
for(let place of placesToTravel) {
    console.log(place);
}