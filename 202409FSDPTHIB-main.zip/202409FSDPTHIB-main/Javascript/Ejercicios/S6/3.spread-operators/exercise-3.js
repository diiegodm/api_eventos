const pointsList = [32, 54, 21, 64, 75, 43];
const pointsList2 = [54,87,99,65,32];

let mergedArray = [...pointsList, ...pointsList2];