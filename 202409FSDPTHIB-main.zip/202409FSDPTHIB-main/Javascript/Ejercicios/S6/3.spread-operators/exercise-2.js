const toy = {name: 'Bus laiyiar', date: '20-30-1995', color: 'multicolor'};
let newObject = {...toy};