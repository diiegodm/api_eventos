const fruits = ['Banana', 'Strawberry', 'Orange'];

let [fruit1, fruit2, fruit3] = fruits;
console.log(fruit1, fruit2, fruit3);