const sum = (a = 10, b = 5) => {
    console.log(a + b);
}

sum();
sum(5);
sum(30, 20);