const numbers = [32, 21, 63, 95, 100, 67, 43];

let number100 = numbers.find(n => n === 100);
console.log(number100);