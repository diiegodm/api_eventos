# Español
Crea una función que escriba un texto y haz que se ejecute cada segundo. A la décima ejecución que se detenga.
