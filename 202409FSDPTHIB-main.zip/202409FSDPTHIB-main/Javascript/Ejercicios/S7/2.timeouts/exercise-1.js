function consoleText() {
    console.log('Hola');
}

setTimeout(consoleText, 3000);