# Español
Crea una función que imprima un texto y haz que se ejecute dentro de 3 segundos.
