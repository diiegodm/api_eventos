let y = 10;
let z = 5;

let x = y * z;
console.log(x);