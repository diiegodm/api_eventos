let carName = 'Volvo';
console.log(carName);