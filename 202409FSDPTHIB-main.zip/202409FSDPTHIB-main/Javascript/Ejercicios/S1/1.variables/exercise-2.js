let x = 50;
console.log(x);