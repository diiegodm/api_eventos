//Soy Jon Snow, Tengo 24 años y me gustan los lobos.
let firstName = 'John';
let lastName = 'Snow';
let age = 24;

console.log('Soy ' + firstName + ' ' + lastName + ', Tengo ' + age + ' años y me gustan los lobos.');