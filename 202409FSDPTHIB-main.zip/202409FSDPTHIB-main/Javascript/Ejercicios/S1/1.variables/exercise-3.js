let x = 5;
let y = 10;
let z = x + y;