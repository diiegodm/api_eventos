let $pillado = document.querySelector('p#pillado');
console.log($pillado);