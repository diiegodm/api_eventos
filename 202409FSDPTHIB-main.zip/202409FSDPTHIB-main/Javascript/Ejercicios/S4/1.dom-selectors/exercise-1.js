let $btn = document.querySelector('.showme');
console.log($btn);