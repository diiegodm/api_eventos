//let $elements = document.querySelectorAll('[data-function="testMe"]');
//console.log($elements[2]);

let $thirdElement = document.querySelector('[data-function="testMe"]:nth-child(3)');
console.log($thirdElement);