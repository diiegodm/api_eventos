let $ps = document.querySelectorAll('p');
for(let $p of $ps) {
    console.log($p);
}