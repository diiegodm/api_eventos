let $elements = document.querySelectorAll('[data-function="testMe"]');
for(let $element of $elements) {
    console.log($element);
}