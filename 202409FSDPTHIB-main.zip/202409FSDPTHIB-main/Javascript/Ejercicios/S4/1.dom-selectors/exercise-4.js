let $pokemons = document.querySelectorAll('.pokemon');
for(let $pokemon of $pokemons) {
    console.log($pokemon);
}