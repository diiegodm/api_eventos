let $element = document.querySelector('.fn-remove-me');
$element.remove();