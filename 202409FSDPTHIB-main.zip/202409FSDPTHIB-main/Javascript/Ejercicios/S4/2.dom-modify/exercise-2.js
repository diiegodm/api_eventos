let $div = document.createElement('div');

//Opcion 1
//let $p = document.createElement('p');
//$div.appendChild($p);

//Opcion 2
$div.innerHTML = '<p></p>';

document.body.appendChild($div);