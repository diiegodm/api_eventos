let $removeMe = document.querySelectorAll('.fn-remove-me');
for(let $element of $removeMe) {
    $element.remove();
}