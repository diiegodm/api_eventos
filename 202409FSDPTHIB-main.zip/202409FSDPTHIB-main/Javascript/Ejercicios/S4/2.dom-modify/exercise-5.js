let $title = document.querySelector('h2.fn-insert-here');
$title.textContent = 'Wubba lubba dub dub!'