function getGreater(numberOne , numberTwo) {
    return numberOne > numberTwo ? numberOne : numberTwo;
}

console.log(getGreater(10, 2));
console.log(getGreater(2, 5));
console.log(getGreater(4, 4));
