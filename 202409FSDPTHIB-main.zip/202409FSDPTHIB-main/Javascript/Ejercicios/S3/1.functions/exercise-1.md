Completa la función que tomando dos números como argumento devuelva el más alto.

```js
function sum(numberOne , numberTwo) {
  // insert code
}
```