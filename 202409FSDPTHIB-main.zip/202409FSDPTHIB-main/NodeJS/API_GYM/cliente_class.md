# insert

idCliente, idClass, time

# buscar a las clases que asitio un cliente
