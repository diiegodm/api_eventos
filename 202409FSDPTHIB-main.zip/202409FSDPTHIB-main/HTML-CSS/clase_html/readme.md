## HTML

Contenido de la web, textos, enlaces, imágenes, parrafos, formularios
semántica --> el significado que tiene cada etiqueta <article> </article> // <section> </section>
sintaxis --> las reglas de escritura, cómo se escribe el lenguaje <div> </div>

## CSS

Lenguaje para aplicar estilos a la web, posicion, colores, tamaños, responsive

## lenguajes de programación

Java, javascript, C++, python, condicionales, operadores logicos, funciones, metodos, bucles, variables
