- mobile first --> siempre empezar en la version movil <meta name="viewport" content="width=device-width, initial-scale=1.0" />
- la imagenes sieempre deberian adaptarse al contenedor
  img{
  width:100%,
  height:auto;
  display:block;
  }

- Usar medidas porcentuales, valores min o max ( min-width:300px) (max-width:500px)
- mediaqueries--> es css dentro de otro css--> cambiar tamaños de cajas, organizacion de cajas, mostrar u ocultar seccions, tamaño de la letra - mobile first hasta 430px moviles pequeños - breakpoint --> min-width:435px --> moviles grandes - breakpoint --> min-width:768px --> tables - breakpoint --> min-width:1024px --> ordenadores
