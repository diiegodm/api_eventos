// Los tipos más comunes son: string, number, boolean, null, undefined, object, Array, Tuple, enum, any, void
